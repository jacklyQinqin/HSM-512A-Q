
#ifndef __UPGRADE_TOOL_H__
#define __UPGRADE_TOOL_H__

#define SM2_READY  0X00
#define SM2_BUSY   0X01

#endif
