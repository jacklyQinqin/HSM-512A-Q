/*
 * @Author: qinxd qinxd@istecc.com
 * @Date: 2021-04-19 15:08:39
 * @LastEditors: qinxd qinxd@istecc.com
 * @LastEditTime: 2022-12-09 16:39:03
 * @FilePath: \SKF-IMX8-IS32U512A\DownLoadFile.h
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * 
 */
#ifndef __DOWNLOADFILE_H__
#define __DOWNLOADFILE_H__


//version 1.8.8.4
// #define MAX_LINE 123
//version 1.8.8.5
// #define MAX_LINE 123
//version 1.8.8.6
//#define MAX_LINE 126
//version 1.8.8.6 add cos_guide.
//#define MAX_LINE 127
//version 1.8.9.1
//#define MAX_LINE 130
//version 1.8.9.2
//#define MAX_LINE 132
//VERSION 1.8.9.3
//#define MAX_LINE 132
//VERSION 1.8.9.4 
//#define MAX_LINE 134
//VERSION 1.8.9.5
#define MAX_LINE 132
//下载COS的函数
//声明数组指针的外部引用
extern const char * arrayPointer[];
#endif


